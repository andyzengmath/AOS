#include "vm/page.h"
#include "threads/pte.h"
#include "vm/frame.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "threads/malloc.h"
#include "filesys/file.h"
#include "string.h"
#include "userprog/syscall.h"
#include "vm/swap.h"

/* Hash function for supplemental page table entries */
unsigned spt_hash_func(const struct hash_elem *e, void *aux UNUSED) {
    const struct supplemental_page_table_entry *spte;
    spte = hash_entry(e, struct supplemental_page_table_entry, spt_elem);

    return hash_bytes(&spte->upage, sizeof(spte->upage));
}

/* Compare function for supplemental page table entries */
bool spt_less_func(const struct hash_elem *a, const struct hash_elem *b, void *aux UNUSED) {
    const struct supplemental_page_table_entry *spte_a;
    const struct supplemental_page_table_entry *spte_b;
    
    spte_a = hash_entry(a, struct supplemental_page_table_entry, spt_elem);
    spte_b = hash_entry(b, struct supplemental_page_table_entry, spt_elem);

    return spte_a->upage < spte_b->upage;
}

/* Initialize the supplemental page table */
void supplemental_page_table_init(struct hash *spt) {
    hash_init(spt, spt_hash_func, spt_less_func, NULL);
}

/* Create and add a new entry to the supplemental page table */
bool supplemental_page_table_add(struct hash *spt, void *upage, bool swapped, bool dirty, bool writable,
                                 struct file *file, size_t offset, size_t page_read_bytes, size_t page_zero_bytes,
                                 bool loaded) {
    struct supplemental_page_table_entry *spte = malloc(sizeof(struct supplemental_page_table_entry));
    if (spte == NULL) {
      return false;
    }

    spte->upage = upage;
    spte->swapped = swapped;
    spte->dirty = dirty;
    spte->writable = writable;
    spte->file = file;
    spte->offset = offset;
    spte->page_read_bytes = page_read_bytes;
    spte->page_zero_bytes = page_zero_bytes;
    spte->loaded = loaded;

    struct hash_elem *result = hash_insert(spt, &spte->spt_elem);
    if (result != NULL) {
        return false;
    }
    return true;
}

/* Find and return a supplemental page table entry */
struct supplemental_page_table_entry *
supplemental_page_table_find(struct hash *spt, void *upage) {

    struct supplemental_page_table_entry spte;

    spte.upage = upage;
    struct hash_elem *e = hash_find(spt, &spte.spt_elem);

    return e != NULL ? hash_entry(e, struct supplemental_page_table_entry, spt_elem) : NULL;
}

/* Remove an entry from the supplemental page table */
void supplemental_page_table_remove(struct hash *spt, void *upage) {
    struct supplemental_page_table_entry spte;
    spte.upage = upage;
    struct hash_elem *e = hash_delete(spt, &spte.spt_elem);
    if (e != NULL) {
        struct supplemental_page_table_entry *spte = hash_entry(e, struct supplemental_page_table_entry, spt_elem);
        free(spte);
    }
}

/* Free all entries in the supplemental page table */
// free_suppl_pt
void supplemental_page_table_destroy(struct hash *spt) {
    hash_destroy(spt, supplemental_page_table_entry_destructor);
}

/* Destructor function for supplemental page table entries */
/* Free supplemental page entry represented by the given hash element in hash table */
void supplemental_page_table_entry_destructor(struct hash_elem *e, void *aux UNUSED) {
    struct supplemental_page_table_entry *spte
        = hash_entry(e, struct supplemental_page_table_entry, spt_elem);

    if (spte->swapped) {
        vm_swap_free(spte->swap_index);
    }

    free(spte);
}

/* insert the given supplemental page table entry */
bool insert_suppl_pte(struct hash *spt, struct supplemental_page_table_entry *spte) {
    struct hash_elem *result;

    if (spte == NULL) {
        return false;
    }

    result = hash_insert(spt, &spte->spt_elem);
    if (result != NULL) {
        return false;
    }

    return true;
}

/* Load page data to the page defined in struct supplemental_page_table_entry. */
bool load_page(struct supplemental_page_table_entry *spte) {
    bool success = false;

    if (spte->file != NULL) {
        success = load_page_file(spte);
    } else if (spte->swapped) {
        success = load_page_swap(spte);
    }

    return success;
}

/* Load page data to the page defined in struct supplemental_page_table_entry from the given file */
bool load_page_file(struct supplemental_page_table_entry *spte) {
    // Implementation specific to loading a file-backed page into memory
    struct thread *cur = thread_current ();
    file_seek(spte->file, spte->offset);

    /* Get a page of memory. */
    uint8_t *kpage = vm_allocate_frame(PAL_USER);
    if (kpage == NULL) {
        return false;
    }

    /* Load this page. */
    if (file_read (spte->file, kpage, spte->page_read_bytes) != (int) spte->page_read_bytes) {
        vm_free_frame(kpage);
        return false; 
    }

    memset (kpage + spte->page_read_bytes, 0, spte->page_zero_bytes);

    /* Add the page to the process's address space. */
    if (!pagedir_set_page (cur->pagedir, spte->upage, kpage, spte->writable)) {
        vm_free_frame (kpage);
        return false; 
    }

    spte->loaded = true;
    return true;

}

/* Load a zero page whose details are defined in struct supplemental_page_table_entry */
bool load_page_swap(struct supplemental_page_table_entry *spte) {
    // Implementation specific to loading a swapped-out page back into memory

    struct thread *cur = thread_current ();

    /* Get a page of memory. */
    uint8_t *kpage = vm_allocate_frame (PAL_USER);
    if (kpage == NULL) {
        return false;
    }

    /* Map the user page to given frame */
    if (!pagedir_set_page (cur->pagedir, spte->upage, kpage, spte->swap_writable)) {
        vm_free_frame (kpage);
        return false;
    }

    /* Swap data from disk into memory page */
    vm_swap_read(spte->swap_index, spte->upage);

    if (spte->swapped) {
        /* After swap in, remove the corresponding entry in suppl page table */
        hash_delete(&cur->suppl_page_table, &spte->spt_elem);
    }

    if (spte->swapped && spte->file != NULL) {
        spte->loaded = true;
    }

    return true;
}

/* Grow stack by one page where the given address points to */
// void grow_stack (void *upage) {
//   void *spage;
//   struct thread *cur = thread_current ();
//   spage = vm_allocate_frame (PAL_USER | PAL_ZERO);
//   if (spage == NULL) {
//     return;
//   } else {
//         /* Add the page to the process's address space. */
//         if (!pagedir_set_page (t->pagedir, pg_round_down (upage), spage, true)) {
//             vm_free_frame (spage); 
//         }
//     }
// }

bool grow_stack(void *fault_addr)
{
//   void *esp = thread_current()->user_esp;
//   uint8_t *stack_bottom = PHYS_BASE - STACK_SIZE;

//   // Check if the faulting address is within the stack region
//   if (fault_addr < stack_bottom) {
//     return false;
//   }

//   // Calculate the number of additional pages needed
//   size_t pages_needed = ((uint8_t *)fault_addr - (uint8_t *)esp) / PGSIZE + 1;

//   // Allocate and map additional stack pages
//   for (size_t i = 0; i < pages_needed; i++) {
//     void *new_page = vm_allocate_frame(PAL_USER | PAL_ZERO);
//     if (new_page == NULL)
//       return false;
    
//     if (!install_page(((uint8_t *)esp) - PGSIZE, new_page, true))
//     {
//       vm_free_frame(new_page);
//       return false;
//     }
//     esp = ((uint8_t *)esp) - PGSIZE;
//   }

//   thread_current()->user_esp = esp;

    // Allocate and map additional stack pages
    struct thread *t = thread_current ();
    void *new_page = vm_allocate_frame(PAL_USER | PAL_ZERO);
    if (new_page == NULL) {
        return false;
    } else {
        // Add the page to the process's address space
        if (!pagedir_set_page (t->pagedir, pg_round_down (fault_addr), new_page, true)) {
            vm_free_frame (new_page);
            return false;
        }
    }
    return true;
}