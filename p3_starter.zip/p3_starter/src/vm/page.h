#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <stdbool.h>
#include "threads/thread.h"
#include "vm/frame.h"
#include "lib/kernel/hash.h"

/* Mention in doc, limiting stack to 8 MB */
#define STACK_SIZE 0x800000

/* Structure to represent a supplemental page table entry */
struct supplemental_page_table_entry {
    void *upage;                    // User virtual address of the page
    // enum page_type tyep;            // Page type
    bool dirty;                     // Indicates if the page has been modified
    bool loaded;                    // Indicates if the page is loaded into memory
    struct hash_elem spt_elem;      // List element for the SPT
    
    // swap
    bool swapped;                   // Indicates if the page is swapped out
    int swap_index;              // Swap slot index
    bool swap_writable;             // Swap writable?

    // file-related data
    struct file *file;              // Pointer to the file mapped to the page
    size_t offset;                  // Offset within the file
    size_t page_read_bytes;         // Number of bytes to read from the file
    size_t page_zero_bytes;         // Number of zero bytes to add
    bool writable;                  // Indicates if the page is writable
};

/* Functions required by hash table */
unsigned spt_hash_func(const struct hash_elem *e, void *aux UNUSED);
bool spt_less_func(const struct hash_elem *a, const struct hash_elem *b, void *aux UNUSED);

/* Initialize the supplemental page table */
void supplemental_page_table_init(struct hash *spt);

/* Create and add a new entry to the supplemental page table */
bool supplemental_page_table_add(struct hash *spt, void *upage, bool swapped, bool dirty, bool writable,
                                 struct file *file, size_t offset, size_t page_read_bytes, size_t page_zero_bytes,
                                 bool loaded);

/* Find and return a supplemental page table entry */
struct supplemental_page_table_entry *supplemental_page_table_find(struct hash *spt, void *upage);

/* Remove an entry from the supplemental page table */
void supplemental_page_table_remove(struct hash *spt, void *upage);

/* Free all entries in the supplemental page table */
void supplemental_page_table_destroy(struct hash *spt);

/* Destructor function for supplemental page table entries */
void supplemental_page_table_entry_destructor(struct hash_elem *e, void *aux UNUSED);

// Insert the given supplemental page table entry
bool insert_suppl_pte(struct hash *spt, struct supplemental_page_table_entry *spte);

/* Add a file supplemental page table entry to the current thread's
 * supplemental page table */
bool suppl_pt_insert_file ( struct file *, off_t, uint8_t *, 
			    uint32_t, uint32_t, bool);

/* Load page data to the page defined in struct supplemental_page_table_entry. */
bool load_page (struct supplemental_page_table_entry *);

// Helpers to load page
bool load_page_file (struct supplemental_page_table_entry *);
bool load_page_swap (struct supplemental_page_table_entry *);

/* Grow stack by one page where the given address points to */
bool grow_stack (void *);

#endif /* vm/page.h */
