#include "vm/swap.h"
#include "devices/block.h"
#include <bitmap.h>
#include "threads/synch.h"
#include "threads/vaddr.h"

/* Sectors needed to store a page*/
#define SECTORS_PER_PAGE (PGSIZE / BLOCK_SECTOR_SIZE)

/* Block device that contains the swap */
struct block *swap_device;
/* Bitmap of swap slot availablities and corresponding lock */
struct bitmap *swap_bitmap;
struct lock swap_lock;

/* Initialize the swap system */
void vm_swap_init(void) {
    // Init the swap device
    swap_device = block_get_role(BLOCK_SWAP);
    if (swap_device == NULL) {
        PANIC("Swap block device not found");
    }

    // Init the swap bitmap
    swap_bitmap = bitmap_create(block_size(swap_device) / SECTORS_PER_PAGE);
    if (swap_bitmap == NULL) {
        PANIC("Failed to create swap bitmap");
    }

    // Mark all swap slots as free
    bitmap_set_all(swap_bitmap, false);

    lock_init(&swap_lock);
}

/* Write the content of a frame to a swap slot */
size_t vm_swap_write(void *frame) {
    lock_acquire(&swap_lock);
    
    // Find a swap slot and mark it in use
    size_t swap_index = bitmap_scan_and_flip(swap_bitmap, 0, 1, false);
    if (swap_index == BITMAP_ERROR) {
        lock_release(&swap_lock);
        return SWAP_ERROR;
    }

    // Write the data to the swap slot
    for (int i = 0; i < SECTORS_PER_PAGE; i++) {
        block_write(swap_device, swap_index * SECTORS_PER_PAGE + i,
                    ((uint8_t *)frame + i * BLOCK_SECTOR_SIZE));
    }

    lock_release(&swap_lock);
    return swap_index;
}

/* Read the content of a swap slot into a frame */
void vm_swap_read(size_t swap_index, void *frame) {
    lock_acquire(&swap_lock);
    // ASSERT(bitmap_test(swap_bitmap, swap_index));

    // Swap out the data from the swap slot to memory
    for (int i = 0; i < SECTORS_PER_PAGE; i++) {
        block_read(swap_device, swap_index * SECTORS_PER_PAGE + i,
                   ((uint8_t *)frame + i * BLOCK_SECTOR_SIZE));
    }
    
    // Free the swap slot bit in bitmap
    bitmap_flip(swap_bitmap, swap_index);

    lock_release(&swap_lock);
}

/* Free a swap slot */
void vm_swap_free(size_t swap_index) {
    lock_acquire(&swap_lock);
    // ASSERT(bitmap_test(swap_bitmap, swap_index));

    // Free the swap slot bit in bitmap
    bitmap_flip(swap_bitmap, swap_index);
    lock_release(&swap_lock);
}
