#ifndef VM_SWAP_H
#define VM_SWAP_H

#include <stdbool.h>
#include <stddef.h>
#include "devices/block.h"
#include "threads/thread.h"

#define SWAP_ERROR SIZE_MAX

/* Initialize the swap system */
void vm_swap_init(void);

/* Write the content of a frame to a swap slot */
size_t vm_swap_write(void *frame);

/* Read the content of a swap slot into a frame */
void vm_swap_read(size_t swap_index, void *frame);

/* Free a swap slot */
void vm_swap_free(size_t swap_index);

#endif /* vm/swap.h */
