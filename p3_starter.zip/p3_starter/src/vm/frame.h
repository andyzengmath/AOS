#ifndef VM_FRAME_H
#define VM_FRAME_H

#include "threads/thread.h"
#include "threads/palloc.h"

typedef int tid_t;
/* Frame table entry structure */
struct vm_frame {
  void *frame;          // Physical memory frame
  uint32_t *pte;            // Page table entry pointing to this frame
  tid_t owner_tid;          // Thread ID of the process owning the frame
  void *uva;                // User virtual address mapped to this frame
  struct list_elem elem;    // List element for frame table
};

/* Initialize the frame management subsystem */
void vm_frame_init(void);

/* Allocate a physical frame with given allocation flags */
void *vm_allocate_frame(enum palloc_flags flags);

/* Free a physical frame */
void vm_free_frame(void *frame);

/* Set the user virtual address, and page table entry for a frame */
void vm_frame_set_uva_pte(void *frame, uint32_t *pte, void *uva);

/* Evict a frame to be freed and write its content to swap slot or file */
void *evict_frame(void);

// frame_table management helpers
void add_vm_frame_entry (void *);
void remove_vm_frame_entry (void *);
struct vm_frame *get_vm_frame_entry (void *);

/* functionalities needed by eviction*/
// select a frame to evict
struct vm_frame *frame_to_evict (void);
// save evicted frame's content for later swap in
bool save_evicted_frame (struct vm_frame *);


#endif /* vm/frame.h */