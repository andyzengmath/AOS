#include "vm/frame.h"
#include "threads/thread.h"
#include "threads/palloc.h"
#include "threads/malloc.h"
#include "swap.h"
#include "userprog/pagedir.h"
#include <string.h>
#include "threads/vaddr.h"
#include "threads/pte.h"

/* lock to synchronize between processes on frame table and eviction is atomic */
static struct lock vm_lock;

// List of all allocated frames
struct list frame_table;

/* init the frame table and necessary data structure */
void vm_frame_init () {
  list_init (&frame_table);
  lock_init (&vm_lock);
}

/* Allocate a physical frame with given allocation flags */
void *vm_allocate_frame(enum palloc_flags flags) {
    void *frame = NULL;

    // Allocate the page based on the flags
    frame = palloc_get_page(flags);

    // if succeed, add to the frame table
    if (frame != NULL) {
        add_vm_frame_entry(frame);
    } else {
        // if fail, evict one page to swap
        if ((frame = evict_frame ()) == NULL) {
            PANIC ("Evicting frame failed"); // ?
        }
    }
    return frame;
}

/* Free a physical frame */
void vm_free_frame(void *frame) {
    // remove frame table entry from the frame table
    remove_vm_frame_entry(frame);
    // free the frame
    palloc_free_page(frame);
}

/* Set the user virtual address and page table entry for a frame */
void vm_frame_set_uva_pte(void *frame, uint32_t *pte, void *uva) {
    // Get the frame entry
    struct vm_frame *f = get_vm_frame_entry(frame);
    // Set the pte and uva if not null
    if (f != NULL) {
        f->pte = pte;
        f->uva = uva;
    }
}

/* Helper function to add a frame entry to the frame table */
void add_vm_frame_entry(void *frame) {
    struct vm_frame *new_frame = malloc(sizeof(struct vm_frame));
    if (new_frame != NULL) {
        new_frame->frame = frame;
        new_frame->owner_tid = thread_current()->tid;
        new_frame->pte = NULL;
        new_frame->uva = NULL;

        lock_acquire (&vm_lock);
        list_push_back(&frame_table, &new_frame->elem);
        lock_release (&vm_lock);
    }
}

/* Helper function to remove a frame entry from the frame table */
void remove_vm_frame_entry(void *frame) {
    struct list_elem *e;
    lock_acquire (&vm_lock);
    for (e = list_begin(&frame_table); e != list_end(&frame_table); e = list_next(e)) {
        struct vm_frame *f = list_entry(e, struct vm_frame, elem);
        if (f->frame == frame) {
            list_remove(e);
            free(f);
            break;
        }
    }
    lock_release (&vm_lock);
}

/* Helper function to get a frame entry from the frame table */
struct vm_frame *get_vm_frame_entry(void *frame) {
    struct list_elem *e;
    lock_acquire (&vm_lock);
    for (e = list_begin(&frame_table); e != list_end(&frame_table); e = list_next(e)) {
        struct vm_frame *f = list_entry(e, struct vm_frame, elem);
        if (f->frame == frame) {
            lock_release (&vm_lock);
            return f;
        }
    }
    lock_release (&vm_lock);
    return NULL;
}

/* Evict a frame to be freed and write its content to swap slot or file */
void * evict_frame(void) {
    struct thread *cur = thread_current();

    lock_acquire(&vm_lock);

    // Choose a frame to evict using the LRU algorithm
    struct vm_frame *evicted_frame = frame_to_evict();

    if (evicted_frame == NULL) {
        // No frame to evict
        return NULL;
    }

    bool result = save_evicted_frame(evicted_frame);
    if (!result) {
        // Cannot save evicted frame
        return NULL;
    }

    // Some clean up
    evicted_frame->owner_tid = cur->tid;
    evicted_frame->pte = NULL;
    evicted_frame->uva = NULL;
    // evicted_frame->pte = NULL; // Clear page table entry
    // evicted_frame->uva = NULL; // Clear user virtual address
    // evicted_frame->tid = TID_ERROR; // Mark frame as invalid

    // // Remove frame from frame table
    // list_remove(&evicted_frame->elem);
    // // Free frame structure
    // free(evicted_frame);

    lock_release(&vm_lock);
    
    // Return evicted frame address
    void *evicted_frame_addr = evicted_frame->frame;
    return evicted_frame_addr;
}

/* Helper function to select a frame for eviction */
struct vm_frame *frame_to_evict(void) {
    // Implementation of frame eviction logic, such as LRU or clock algorithm

    struct vm_frame *vf;
    struct vm_frame *vf_selected = NULL;
    struct thread *t;
    struct list_elem *e;

    e = list_begin (&frame_table);
    while (e != list_end(&frame_table)) {
        vf = list_entry (e, struct vm_frame, elem);
        t = thread_get_by_id (vf->owner_tid);
        bool accessed  = pagedir_is_accessed(t->pagedir, vf->uva);
        if (!accessed) {
            vf_selected = vf;
            list_remove (e);
            list_push_back (&frame_table, e);
            break;
        } else {
            pagedir_set_accessed (t->pagedir, vf->uva, false);
        }
        e = list_next(e);
    }

	return vf_selected;
}

/* Helper function to save the content of an evicted frame for later swap-in */
bool save_evicted_frame(struct vm_frame *evicted_frame) {
    // Implementation of saving the evicted frame's content, possibly to disk or swap

    if (evicted_frame->pte == NULL || !evicted_frame->uva || evicted_frame->owner_tid == TID_ERROR) {
        // Invalid frame, cannot save
        return false;
    }

    /* Get thread associated with vm_frame->owner_tid */
    struct thread *t = thread_get_by_id (evicted_frame->owner_tid);

    /* Get spte associated with vm_frame->uva */
    struct supplemental_page_table_entry *spte
        = supplemental_page_table_find(&t->suppl_page_table, evicted_frame->uva);
    
    /* If no spte found, create and insert one into the suppl page table*/
    if (spte == NULL) {
        spte = calloc(1, sizeof *spte);
        spte->upage = evicted_frame->uva;
        spte->swapped = true;
        if (!insert_suppl_pte (&t->suppl_page_table, spte)) {
            return false;
        }
    }

    size_t swap_index = vm_swap_write(evicted_frame->frame);
    if (swap_index == SWAP_ERROR) {
        // Swap write failed, unable to save
        return false;
    }
    spte->swapped = true;
    // size_t swap_index;
    // if (pagedir_is_dirty (t->pagedir, spte->upage) || (spte->file == NULL)) {
    //     swap_index = vm_swap_write(spte->upage);
    //     if (swap_index == SWAP_ERROR) {
    //         return false;
    //     }
    //     spte->swapped = true;
    // } 
    // Else: page clean or RO, nothing is done

    memset (evicted_frame->frame, 0, PGSIZE);
    /* update the swap attributes, including swap_slot_idx, and swap_writable */
    spte->swap_index = swap_index;
    spte->swap_writable = *(evicted_frame->pte) & PTE_W;
    spte->loaded = false;

    /* unmap it from user's pagedir, free vm page/frame */
    pagedir_clear_page(t->pagedir, spte->upage);

    return true;
}